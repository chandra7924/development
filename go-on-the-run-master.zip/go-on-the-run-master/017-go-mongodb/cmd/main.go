// using mgo package - https://github.com/globalsign/mgo
package main

func main() {

}
