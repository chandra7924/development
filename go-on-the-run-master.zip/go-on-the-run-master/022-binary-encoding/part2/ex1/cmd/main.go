package main

import "benc/model"
import "fmt"

func main(){
	var cr1 model.ClientReq
	
	fmt.Printf("cr1: %v\n", cr1)
}