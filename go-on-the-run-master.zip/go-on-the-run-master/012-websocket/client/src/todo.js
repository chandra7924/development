export class Todo{
  constructor(description) {
    this.id = 0;
    this.description = description;
    this.done = false;
  }
}
