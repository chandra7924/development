package main

// people is sample table with the following structures
// ID(int) | Fname(string) | Lname(string) | Age(uint8) | Height(float64)
// --------+---------------+---------------+------------+-----------------
// 1       | Jane          | Doe           | 41         | 5.5
// 2       | Mark          | Smith         | 23         | 5.9
// 3       | Anne          | Marie         | 89         | 5.2
