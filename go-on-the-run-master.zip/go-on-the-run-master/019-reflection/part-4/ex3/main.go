package main

func main() {
	dumpData(PeopleData)
}
