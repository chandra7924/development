# Go on the Run (gotr) by Striversity
This is the source code for the YouTube series covering a 
wide range of topics in the Go (golang) programming language.

Videos are uploaded at lease every other Saturday monring.

Think of this series as a set of HowTo videos.

Subscribe to keep updated at YouTube: https://www.youtube.com/playlist?list=PL0aDKsruoiW2jac2D2flxZofQLfEOc2GU

